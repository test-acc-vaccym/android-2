package org.openintents.sensorsimulator.record;

public class Global {

	protected static final int PORT = 9100;

}
